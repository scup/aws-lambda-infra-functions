module.exports = {
  logLevel: process.env.LOG_LEVEL || 'info'
}
