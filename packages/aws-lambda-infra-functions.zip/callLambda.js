const a = require('./Infra/lambdas/kinesisToGraphql')

a({
  records: [{ a: 'record' }]
}, null, console.log.bind(console, 'CALLBACK:\n', '#'.repeat(80), '\n'))
