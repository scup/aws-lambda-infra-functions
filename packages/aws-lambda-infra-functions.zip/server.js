const express = require('express')
const bodyParser = require('body-parser')

const server = express()

server.use(bodyParser.json())

server.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*')
  res.header('Access-Control-Allow-Headers', 'Content-Type')
  next()
})

server.use('/api', (req, res) => {
  console.log('#'.repeat(40))
  console.log('req.body:::', require('util').inspect(req.body, { depth: 4 }))
  console.log('#'.repeat(40))
  res.status(200).send({
    data: 'ok'
  })
})

server.listen(9001, console.log.bind(console, 'Server is running on 9001'))
